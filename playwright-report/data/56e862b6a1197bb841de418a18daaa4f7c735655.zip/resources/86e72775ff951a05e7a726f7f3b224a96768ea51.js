(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__8ebb6d4b._.css",
  "static/chunks/node_modules_720020fb._.js",
  "static/chunks/src_1e6b98cc._.js"
],
    source: "dynamic"
});
